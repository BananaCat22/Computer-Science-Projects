public  class ExpressLane extends Lane {
    public ExpressLane(){
        super(0.10, 1.0, true);
    }
    
}
