public class NormalLane extends Lane {
    public NormalLane()
    {
        super(0.05, 2.0,false);
    }
    
}
